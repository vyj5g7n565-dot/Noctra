#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
APP_PATH="${APP_PATH:-${PROJECT_ROOT}/build/Source/ui_ios/Release-iphoneos/Play.app}"
OUTPUT_PATH="${OUTPUT_PATH:-${SCRIPT_DIR}/Play.ipa}"
PAYLOAD_DIR="${SCRIPT_DIR}/Payload"

if [[ ! -d "${APP_PATH}" ]]; then
  echo "ERROR: Play.app was not found: ${APP_PATH}" >&2
  echo "Build the iOS target first, or set APP_PATH to the built .app directory." >&2
  exit 1
fi

rm -rf "${PAYLOAD_DIR}"
mkdir -p "${PAYLOAD_DIR}"

if command -v ditto >/dev/null 2>&1; then
  ditto "${APP_PATH}" "${PAYLOAD_DIR}/Play.app"
else
  cp -R "${APP_PATH}" "${PAYLOAD_DIR}/Play.app"
fi

rm -f "${OUTPUT_PATH}"
(
  cd "${SCRIPT_DIR}"
  /usr/bin/zip -qry "${OUTPUT_PATH}" Payload
)

if ! /usr/bin/unzip -tq "${OUTPUT_PATH}" >/dev/null; then
  echo "ERROR: generated IPA failed its ZIP integrity check." >&2
  exit 1
fi

echo "IPA created: ${OUTPUT_PATH}"
