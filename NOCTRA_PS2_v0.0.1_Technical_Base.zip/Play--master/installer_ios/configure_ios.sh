#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-${PROJECT_ROOT}/build}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: iOS compilation requires macOS with Apple's iOS SDK and Xcode." >&2
  exit 1
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "ERROR: xcodebuild is unavailable. Install Xcode and its command-line tools." >&2
  exit 1
fi
if ! command -v cmake >/dev/null 2>&1; then
  echo "ERROR: CMake is unavailable. Install CMake first." >&2
  exit 1
fi

required=(
  "${PROJECT_ROOT}/deps/Dependencies/cmake-ios/ios.cmake"
  "${PROJECT_ROOT}/deps/Framework/CMakeLists.txt"
  "${PROJECT_ROOT}/deps/CodeGen/CMakeLists.txt"
  "${PROJECT_ROOT}/deps/Nuanceur/CMakeLists.txt"
  "${PROJECT_ROOT}/deps/libchdr/CMakeLists.txt"
  "${PROJECT_ROOT}/deps/AltKit/CMakeLists.txt"
)
missing=()
for path in "${required[@]}"; do
  [[ -e "${path}" ]] || missing+=("${path#${PROJECT_ROOT}/}")
done
if (( ${#missing[@]} )); then
  echo "ERROR: required source dependencies are missing:" >&2
  printf '  - %s\n' "${missing[@]}" >&2
  echo "This source ZIP contains .gitmodules but not the submodule contents." >&2
  echo "Use a Git checkout with recursive submodules before configuring." >&2
  exit 2
fi

mkdir -p "${BUILD_DIR}"
cd "${BUILD_DIR}"
cmake "${PROJECT_ROOT}" \
  -G Xcode \
  -DCMAKE_TOOLCHAIN_FILE="${PROJECT_ROOT}/deps/Dependencies/cmake-ios/ios.cmake" \
  -DTARGET_IOS=ON \
  -DCMAKE_OSX_ARCHITECTURES=arm64 \
  -DBUILD_TESTS=OFF \
  -DBUILD_PSFPLAYER=OFF \
  -DBUILD_LIBRETRO_CORE=OFF \
  -DCMAKE_XCODE_ATTRIBUTE_CODE_SIGNING_ALLOWED=NO

echo "iOS Xcode project configured in: ${BUILD_DIR}"
echo "Next: cmake --build \"${BUILD_DIR}\" --config Release --target Play"
